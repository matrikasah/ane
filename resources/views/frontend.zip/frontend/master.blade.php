@include('frontend.partical.header')

@yield('content')


@include('frontend.partical.footer')